import 'package:flutter/material.dart';

class ScanPageController extends ChangeNotifier{
  
}