
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../FeedCreationcontroller/FeedCrtController.dart';

class VideoController extends ChangeNotifier {
 

}